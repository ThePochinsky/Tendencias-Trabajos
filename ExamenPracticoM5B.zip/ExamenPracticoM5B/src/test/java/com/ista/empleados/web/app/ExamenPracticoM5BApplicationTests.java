package com.ista.empleados.web.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenPracticoM5BApplicationTests {

	@Test
	void contextLoads() {
	}

}
